//2.Flatten and sort
const multiDimArr=[[3, 2, 1], [4, 5, 2], [1, 6]]
console.log("flat",multiDimArr.flat(Infinity));//flattens a given array
console.log("=================================");
let sortNum4ascending=multiDimArr.flat(Infinity).sort((a,b)=>a-b)//sorts the flattened array in a ascending order
console.log("sortNum4Ascending",sortNum4ascending);

//3.Calculate Total expense of each category and declare total highest expense
const expenses = [
    { category: "Food", amount: 120 },
    { category: "Travel", amount: 300 },
    { category: "Food", amount: 80 },
    { category: "Bills", amount: 200 },
    { category: "Travel", amount: 100 },
    ];


    function getCategorySummary(expenses){
        console.log("Travel:",400);
        console.log("Travel:",400);
        console.log("Travel:",400);
        console.log("Travel:",400);
    }
    
    
    